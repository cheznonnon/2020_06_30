// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




//#include "../nonnon/neutral/string.c"




#define N_VIEWER_MSG WM_NULL




static s32      n_viewer_font_sx = 0;
static s32      n_viewer_font_sy = 0;
static WNDPROC  n_viewer_pfunc   = NULL;




#define N_VIEWER_REFRESH( hwnd       ) SendMessage( hwnd, N_VIEWER_MSG,    0,0 )
#define N_VIEWER_SETLINE( hwnd, line ) SendMessage( hwnd, N_VIEWER_MSG, line,0 )

// internal
void
n_viewer_draw( HWND hwnd, s32 fy, s32 ty )
{

	if ( fy < 0 ) { fy = 0; }
	if ( ty < 0 ) { ty = 0; }

	if ( fy > txt.sy ) { fy = txt.sy; }
	if ( ty > txt.sy ) { ty = txt.sy; }

	if ( fy > ty ) { fy = ty; }


	int i;
	int horzpos;


	horzpos = GetScrollPos( hwnd, SB_HORZ );


	n_win_redraw_off( hwnd );

	n_win_listbox_reset( hwnd );


	i = fy;
	while( 1 )
	{

		n_win_listbox_set( hwnd, txt.line[ i ] );


		i++;
		if ( i >= ty ) { break; }
	}

n_win_listbox_set( hwnd, n_posix_literal("+++ Last Line +++") );


	// Check : don't use SetScrollPos() : position will be zero

	N_HSCROLL_POS_SET( hwnd, NULL, horzpos );

	n_win_redraw_on( hwnd );


	return;
}

// internal
LRESULT CALLBACK
n_viewer_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static bool init   = false;
	static bool scroll = false;


	MSG struct_msg;


	switch( msg ) {


	case N_VIEWER_MSG :

		scroll = init = true;

	break;

	case WM_SIZE    :
	case WM_VSCROLL :

		scroll = true;

	break;

	case WM_LBUTTONDOWN   :
	case WM_LBUTTONDBLCLK :

		// this means "never focus"
		// so cannot support mouse wheel scrolling directly

		PeekMessage( &struct_msg, NULL,0,0,PM_REMOVE );

		return 0;

	break;


	} // switch


	if ( scroll )
	{

		static SCROLLINFO si = { sizeof(SCROLLINFO), SIF_ALL, 0,0,0,0,0 };


		RECT rect;


		scroll = false;


		if ( init )
		{

			init = false;


			si.nPos = 0;
			si.nMax = txt.sy - 1;

			SendMessage( hwnd, LB_SETHORIZONTALEXTENT, txt.sx * n_viewer_font_sx, 0 );

			N_HSCROLL_POS_SET( hwnd, NULL, 0 );

		}


		if ( msg == N_VIEWER_MSG )
		{
			si.nPos = wparam;
			wparam  = SB_ENDSCROLL;
		}


		// integer only : don't use (double)

		GetClientRect( hwnd, &rect );

		si.nPage = (u32) rect.bottom / n_viewer_font_sy;

//n_win_hwndprintf_literal( GetParent( hwnd ), "%d %d", (int) txt.sx, (int) txt.sy );
//n_win_hwndprintf_literal( GetParent( hwnd ), "%d %d : %d", si.nMax, si.nPage, (int)rect.bottom );


		switch( LOWORD( wparam ) ) {

		case SB_LINEUP :

			si.nPos -= 1;

		break;
		case SB_LINEDOWN :

			si.nPos += 1;

		break;

		case SB_PAGEUP :

			si.nPos -= si.nPage;

		break;
		case SB_PAGEDOWN :

			si.nPos += si.nPage;

		break;

		case SB_TOP :

			si.nPos = 0;

		break;
		case SB_BOTTOM :

			si.nPos = txt.sy;

		break;

		case SB_THUMBPOSITION :
		case SB_THUMBTRACK    :

			// 16bit only : si.nPos = HIWORD( wparam );

			GetScrollInfo( hwnd, SB_VERT, &si );
			si.nPos = si.nTrackPos;

		break;

		} // switch


		if ( si.nPage > txt.sy )
		{
			si.nPos = 0;
		}

		if ( si.nPos < 0 )
		{
			si.nPos = 0;
		}
		if ( si.nPos >= ( txt.sy - si.nPage ) )
		{
			si.nPos = txt.sy - si.nPage;
		}


		n_viewer_draw( hwnd, si.nPos, si.nPos + si.nPage );

		SetScrollInfo( hwnd, SB_VERT, &si, true );


//n_win_hwndprintf( GetParent( hwnd ), "%d %d", tmp, si.nPos );


		return 0;
	}


	return CallWindowProc( n_viewer_pfunc, hwnd, msg, wparam, lparam );
}

void
n_viewer_hfont_set( HWND hwnd_ctl, HFONT hfont, bool redraw )
{

	// Win95 : HFONT hasn't fontsize sometimes
	//
	// 16pt will be 18pt, but 18pt will be different size


	n_win_font_set( hwnd_ctl, hfont, redraw );

	n_win_stdsize_text( hwnd_ctl, n_posix_literal("a"), &n_viewer_font_sx, &n_viewer_font_sy );


	return;
}

void
n_viewer_load( HWND hwnd, HWND *hwnd_ctl )
{

	if ( hwnd     == NULL ) { return; }
	if ( hwnd_ctl == NULL ) { return; }


	(*hwnd_ctl) = CreateWindowEx
	(
		WS_EX_CLIENTEDGE,
		n_posix_literal("LISTBOX"),
		N_STRING_EMPTY,
		WS_CHILD | WS_VISIBLE | WS_HSCROLL |
		LBS_NOSEL             |
		LBS_USETABSTOPS       |
		LBS_NOINTEGRALHEIGHT,
		0,0, 0,0,
		hwnd,
		(HMENU) NULL,
		GetModuleHandle( NULL ),
		NULL 
	);

	n_viewer_pfunc = n_win_gui_subclass_set( (*hwnd_ctl), n_viewer_subclass );


	return;
}

void
n_viewer_free( void )
{
	return;
}

