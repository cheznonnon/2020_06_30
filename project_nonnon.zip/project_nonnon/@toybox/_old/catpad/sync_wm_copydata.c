// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// [x] : identity confusion might occur




extern n_posix_char searchstr[];
extern void n_catpad_search_add( void );



static HANDLE hmutex = NULL;




void
n_catpad_sync_init( void )
{

	hmutex = CreateMutex( NULL, TRUE, n_posix_literal( "CatPad.Sync" ) );


	return;
}

void
n_catpad_sync_exit( void )
{

	ReleaseMutex( hmutex );
	CloseHandle ( hmutex );


	return;
}

// internal
BOOL CALLBACK
n_catpad_sync_enumwindows( HWND hwnd, LPARAM lparam )
{

	if ( n_win_class_is_same_literal( hwnd, "window #0" ) )
	{

		COPYDATASTRUCT cds;


		cds.dwData = (DWORD) hmutex;
		cds.cbData = N_PATH_MAX * sizeof( n_posix_char );
		cds.lpData = searchstr;


		n_win_message_send( hwnd, WM_COPYDATA, (HWND) lparam, &cds );

	}


	return true;
}

void
n_catpad_sync_send( HWND hwnd )
{

	EnumWindows( n_catpad_sync_enumwindows, (LPARAM) hwnd );


	return;
}

void
n_catpad_sync_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	HWND            h   = (HWND)  wparam;
	COPYDATASTRUCT *cds = (void*) lparam;
	DWORD           mtx = (DWORD) hmutex;


	if ( msg != WM_COPYDATA ) { return; }

	if ( hwnd ==    h ) { return; }
	if ( cds  == NULL ) { return; }

	if ( cds->dwData != mtx ) { return; }
	if ( cds->cbData != ( N_PATH_MAX * sizeof(n_posix_char) ) { return; }


	n_path_copy( cds->lpData, searchstr );

	n_catpad_search_add();


	return;
}

