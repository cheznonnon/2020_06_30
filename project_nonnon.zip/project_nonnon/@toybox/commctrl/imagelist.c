



// link is needed : -lcomctl32


// [x] : flicker and redraw-error




#include "../../nonnon/win32/win.c"

#include "../../nonnon/project/macro.c"


#include <commctrl.h>




#define N_WIN_IMGELIST_INDEX ( 0 )


typedef struct {

	bool       onoff;
	HWND       hwnd;
	HIMAGELIST h;
	int        x,y,sx,sy, ox,oy;

} n_win_imagelist;




void
n_win_imagelist_new( n_win_imagelist *i, HWND hwnd, const char *icon_name, int x, int y, int sx, int sy )
{

	if ( i == NULL ) { return; }


	InitCommonControls();


	i->onoff    = false;
	i->hwnd     = hwnd;
	i->h        = ImageList_Create( sx,sy, ILC_COLOR32 | ILC_MASK, 1, 0 );

	i->x        = x;
	i->y        = y;
	i->sx       = sx;
	i->sy       = sy;
	i->ox       = 0;
	i->oy       = 0;


	{

		HICON hico = n_win_icon_init( icon_name, N_WIN_ICON_INIT_OPTION_DEFAULT );

		ImageList_AddIcon( i->h, hico );

		n_win_icon_exit( hico );

	}


	return;
}

void
n_win_imagelist_erase( n_win_imagelist *i )
{

	RECT r = n_win_rect_set( NULL, i->x, i->y, i->sx, i->sy );

	InvalidateRect( i->hwnd, &r, TRUE );


	return;
}

void
n_win_imagelist_draw( n_win_imagelist *i )
{

	n_win_imagelist_erase( i );


	HDC hdc = GetDC( i->hwnd );

	ImageList_Draw( i->h, N_WIN_IMGELIST_INDEX, hdc, i->x,i->y, ILD_TRANSPARENT );

	ReleaseDC( i->hwnd, hdc );


	{
		RECT r = n_win_rect_set( NULL, i->x, i->y, i->sx, i->sy );
		ValidateRect( i->hwnd, &r );
	}


	return;
}

bool
n_win_imagelist_is_hovered( n_win_imagelist *i )
{

	if ( i->onoff ) { return false; }

	return n_win_is_hovered_offset( i->hwnd, i->x, i->y, i->sx, i->sy );
}

void
n_win_imagelist_dnd_init( n_win_imagelist *i )
{

	if ( false == n_win_imagelist_is_hovered( i ) ) { return; }
//n_win_hwndprintf_literal( i->hwnd, "%d %d", i->x, i->y ); return;


	SetCapture( i->hwnd );


	s32 x,y; n_win_cursor_position_relative( i->hwnd, &x, &y );

	i->onoff = true;
	i->ox    = x - i->x;
	i->oy    = y - i->y;

	ImageList_BeginDrag( i->h, N_WIN_IMGELIST_INDEX, i->ox, i->oy );


	// [!] : tricky position calculation

	POINT p; GetCursorPos( &p );
	RECT  r; GetWindowRect( i->hwnd, &r );

	p.x = p.x - r.left;
	p.y = p.y - r.top;

	ImageList_DragEnter( i->hwnd, p.x, p.y );


	return;
}

void
n_win_imagelist_dnd_loop( n_win_imagelist *i )
{

	if ( i->onoff == false ) { return; }


	// [!] : tricky position calculation

	POINT p; GetCursorPos( &p );
	RECT  r; GetWindowRect( i->hwnd, &r );

	p.x = p.x - r.left;
	p.y = p.y - r.top;

	ImageList_DragMove( p.x, p.y );


	return;
}

void
n_win_imagelist_dnd_exit( n_win_imagelist *i )
{

	if ( i->onoff == false ) { return; }


	i->onoff = false;


	ImageList_DragLeave( i->hwnd );
	ImageList_EndDrag();

	ReleaseCapture();


	n_win_imagelist_erase( i );

	s32 x,y; n_win_cursor_position_relative( i->hwnd, &x, &y );

	i->x = x - i->ox;
	i->y = y - i->oy;

	n_win_imagelist_draw ( i );


	return;
}

void
n_win_imagelist_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_imagelist *i )
{

	switch( msg ) {


	case WM_PAINT :

		if ( i->onoff ) { break; }

		n_win_imagelist_draw( i );

	break;


	case WM_LBUTTONDOWN :

		n_win_imagelist_dnd_init( i );

	break;

	case WM_MOUSEMOVE :

		n_win_imagelist_dnd_loop( i );

	break;

	case WM_LBUTTONUP :

		n_win_imagelist_dnd_exit( i );

	break;


	} // switch


	return;
}

LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	const int u = 32;


	const char *iconame[ 3 ] = {

		"../../nonnon/project/neko.multi.ico",
		"../../nonnon/project/save.ico",
		"../../nonnon/project/folder.ico",

	};


	static n_win_imagelist imglist[ 3 ];


	switch( msg ) {


	case WM_CREATE :


		n_win_exedir2curdir();


		n_win_init( hwnd, "Nonnon ImageList", "", "" );

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		n_win_set( hwnd, NULL, 256,256, N_WIN_SET_CENTERING );


		n_win_imagelist_new( &imglist[ 0 ], hwnd, iconame[ 0 ], u * 0, u * 0, u,u );
		n_win_imagelist_new( &imglist[ 1 ], hwnd, iconame[ 1 ], u * 1, u * 1, u,u );
		n_win_imagelist_new( &imglist[ 2 ], hwnd, iconame[ 2 ], u * 2, u * 2, u,u );


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_imagelist_proc( hwnd, msg, wparam, lparam, &imglist[ 0 ] );
	n_win_imagelist_proc( hwnd, msg, wparam, lparam, &imglist[ 1 ] );
	n_win_imagelist_proc( hwnd, msg, wparam, lparam, &imglist[ 2 ] );



	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

